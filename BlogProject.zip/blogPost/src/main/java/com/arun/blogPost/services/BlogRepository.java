package com.arun.blogPost.services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.arun.blogPost.model.Blog;

public interface BlogRepository extends JpaRepository<Blog, Integer>{
	
}
