package com.arun.blogPost.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.arun.blogPost.model.Blog;
import com.arun.blogPost.services.BlogRepository;
import com.arun.blogPost.services.BolgServices;

@Controller
public class BlogController {
	
	@Autowired
	BolgServices bolgServices;
	
	@Autowired
	BlogRepository rep;
	
	@RequestMapping(value="/blog-list", method=RequestMethod.GET)
	public String showTodosPage(ModelMap model) {
		//String user = getLoggedInUserName(model);
		model.put("blogs", rep.findAll());
		return "blog-list";
		
	}
	
	@RequestMapping(value="/addBlogs", method=RequestMethod.GET)
	public String addBlogPage(@ModelAttribute("blog") Blog blog, ModelMap model) {
		return "addbolgs";	
	}
	
	@RequestMapping(value="/addBlogs", method=RequestMethod.POST)
	public String addBlogs(@ModelAttribute("blog") Blog blog, ModelMap model) {
		Blog obj = new Blog();
		obj.setTitle(blog.getTitle());
		obj.setDesc(blog.getDesc());
		rep.save(obj);
		return "redirect:/blog-list";	
	}
	private String getLoggedInUserName(ModelMap model) {
		return (String) model.get("userName");
	}
	
	
}
