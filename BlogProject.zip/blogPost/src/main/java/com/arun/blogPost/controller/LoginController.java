package com.arun.blogPost.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.arun.blogPost.model.User;
import com.arun.blogPost.services.UserRepository;

@Controller
public class LoginController {
	
	@Autowired
	UserRepository userRep;
	
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public String registerUser() {	
		return "register";
	}
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public String registerUser(@ModelAttribute("user") User user, ModelMap model) {	
		User obj = new User();
		obj.setUser(user.getUser());
		obj.setEmail(user.getEmail());
		obj.setPassword(user.getPassword());
		userRep.save(obj);
		return "login";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String showloginPage() {
		return "login";	
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String showlogedinUserBlogs() {
		return "redirect:/blog-list";	
	}
}
