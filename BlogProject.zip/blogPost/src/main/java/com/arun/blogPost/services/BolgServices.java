package com.arun.blogPost.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.arun.blogPost.model.Blog;

@Service
public class BolgServices {
	private static List<Blog> blogs = new ArrayList<Blog>();
	
	static {
		blogs.add(new Blog("Learn Java","This Blog Teach you java basics"));
		blogs.add(new Blog("Learn Spring","This Blog Teach you Spring MVC basics"));
	}
	
	public List<Blog> retrieveBlogs(String user) {
		
		return blogs;
	}
	
	public void addTodo(String title, String desc) {
		blogs.add(new Blog(title, desc));
		
	}
}
