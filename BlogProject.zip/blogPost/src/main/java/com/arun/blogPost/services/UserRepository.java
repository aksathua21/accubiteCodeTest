package com.arun.blogPost.services;

import org.springframework.data.jpa.repository.JpaRepository;

import com.arun.blogPost.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {
	

}
